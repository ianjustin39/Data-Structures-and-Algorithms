problem 1 

Queue: because data length max is 5. and I didn't call get function , always put data in queue. I should remove first data.
        and if get data, the data should put on top in queue.
Map: I get data need key-value pairs.

time: O(1)
space: O(n)

---

problem 2

List: put all data in list to use for-loop to check data name.

Recursion: if data is dir, I should use recursion function to get data in dir to check data name

time: O(n^2)
space: O(n)

---

problem 3

List: because I can sort list and use for loop to get data.
Tree: because data

time: O（n log n）
space: O（n）
---

problem 4 
List: put all data in list
Tree: beacause data has list or value in data

time: O（n）
space: O（n）
---

problem 5

LinkedList: Data arranged in order

time: O（n）
space: O（n）
---
problem 6
Set: Information is not repeated
LinkedList: Data arranged in order

union
time: O（n）
space: O（n）

intersection
time: O（n^2）
space: O（n^2）